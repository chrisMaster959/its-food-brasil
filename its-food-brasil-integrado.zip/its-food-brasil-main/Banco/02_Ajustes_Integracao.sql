﻿/* =====================================================================
   ItsFoodBrasil - AJUSTES PARA A INTEGRAÇÃO COM O SISTEMA (.NET)

   Execute DEPOIS do script ItsFoodBrasil_Banco_SQLServer_Atualizado.sql.
   Pode ser executado mais de uma vez (idempotente).

   O que este script faz:
     1. Pessoa.Senha passa de VARCHAR(50) para VARCHAR(255)
        (a senha é gravada como HASH, que é maior que 50 caracteres).
     2. Movimentacao ganha a coluna Categoria
        (a tela de Fluxo de Caixa filtra e exibe a categoria do lançamento).
     3. vw_FluxoCaixa passa a devolver a Categoria
        (vendas sem categoria aparecem como 'Vendas').
     4. sp_RegistrarMovimentacao passa a receber @Categoria.
   ===================================================================== */

USE ItsFoodBrasil;
GO

SET NOCOUNT ON;
GO

-- ---------------------------------------------------------------------
-- 1. Senha em hash
-- ---------------------------------------------------------------------
ALTER TABLE dbo.Pessoa ALTER COLUMN Senha VARCHAR(255) NULL;
GO

-- ---------------------------------------------------------------------
-- 2. Categoria da movimentação
-- ---------------------------------------------------------------------
IF COL_LENGTH(N'dbo.Movimentacao', N'Categoria') IS NULL
    ALTER TABLE dbo.Movimentacao ADD Categoria VARCHAR(50) NULL;
GO

-- Lançamentos manuais antigos (dados de exemplo) ficam com uma categoria coerente.
-- As entradas geradas por venda continuam sem categoria: a view mostra 'Vendas'.
UPDATE dbo.Movimentacao
   SET Categoria = CASE
        WHEN Descricao LIKE 'Pagamento de aluguel%'   THEN 'Despesas'
        WHEN Descricao LIKE 'Pagamento de energia%'   THEN 'Despesas'
        WHEN Descricao LIKE 'Pagamento fornecedor%'   THEN 'Fornecedores'
        WHEN Descricao LIKE 'Compra de mercadorias%'  THEN 'Compras'
        WHEN Descricao LIKE 'Pagamento de frete%'     THEN 'Frete'
        WHEN Descricao LIKE 'Suprimento de caixa%'    THEN 'Suprimento de caixa'
        WHEN Tipo = 'Entrada'                         THEN 'Outras entradas'
        ELSE 'Outras saídas'
   END
 WHERE Categoria IS NULL
   AND IdVenda IS NULL;
GO

-- ---------------------------------------------------------------------
-- 3. View do fluxo de caixa com a categoria
-- ---------------------------------------------------------------------
CREATE OR ALTER VIEW dbo.vw_FluxoCaixa
AS
SELECT  m.IdMovimentacao,
        m.DataMovimentacao,
        m.Descricao,
        m.Tipo,
        m.Valor,
        CASE WHEN m.Tipo = 'Entrada' THEN m.Valor ELSE -m.Valor END AS ValorComSinal,
        CASE WHEN m.IdVenda IS NOT NULL THEN 'Venda' ELSE 'Manual' END AS Origem,
        m.IdVenda,
        m.IdFuncionario,
        pe.Nome AS Funcionario,
        COALESCE(m.Categoria,
                 CASE WHEN m.IdVenda IS NOT NULL THEN 'Vendas'
                      WHEN m.Tipo = 'Entrada'    THEN 'Outras entradas'
                      ELSE 'Outras saídas' END) AS Categoria
FROM dbo.Movimentacao m
LEFT JOIN dbo.Pessoa  pe ON pe.IdPessoa = m.IdFuncionario;
GO

-- ---------------------------------------------------------------------
-- 4. Lançamento manual com categoria
-- ---------------------------------------------------------------------
CREATE OR ALTER PROCEDURE dbo.sp_RegistrarMovimentacao
    @Tipo            VARCHAR(10),
    @Valor           DECIMAL(18,2),
    @Descricao       VARCHAR(200),
    @Categoria       VARCHAR(50) = NULL,
    @Data            DATETIME    = NULL,
    @IdFuncionario   INT         = NULL,
    @IdMovimentacao  INT         OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    SET @Descricao = LTRIM(RTRIM(ISNULL(@Descricao, '')));
    SET @Categoria = NULLIF(LTRIM(RTRIM(ISNULL(@Categoria, ''))), '');
    SET @Data = ISNULL(@Data, GETDATE());

    IF @Tipo NOT IN ('Entrada', 'Saída')
        THROW 50400, 'Tipo inválido. Use Entrada ou Saída.', 1;
    IF @Descricao = ''
        THROW 50401, 'Informe a descrição.', 1;
    IF @Valor IS NULL OR @Valor <= 0
        THROW 50402, 'Informe um valor maior que zero.', 1;
    IF @IdFuncionario IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Funcionario WHERE IdPessoa = @IdFuncionario)
        THROW 50403, 'Funcionário não encontrado.', 1;

    INSERT dbo.Movimentacao (Tipo, Valor, Descricao, Categoria, DataMovimentacao, IdFuncionario, IdVenda)
    VALUES (@Tipo, @Valor, @Descricao, @Categoria, @Data, @IdFuncionario, NULL);

    SET @IdMovimentacao = SCOPE_IDENTITY();
END;
GO
