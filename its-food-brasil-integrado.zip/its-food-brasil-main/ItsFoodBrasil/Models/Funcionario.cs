namespace ItsFoodBrasil.Models
{
    public class Funcionario
    {
        public int IdFuncionario { get; set; }

        public int IdPessoa { get; set; }

        public int IdPerfil { get; set; }

        //Ativo ou inativo
        public string Status { get; set; } = string.Empty;


        // FK -> Pessoa
        public Pessoa Pessoa { get; set; } = null!;

        public string Perfil { get; set; } = null!;


        // Relacionamento com Venda
        public ICollection<Venda> Vendas { get; set; }
            = new List<Venda>();
    }
}
